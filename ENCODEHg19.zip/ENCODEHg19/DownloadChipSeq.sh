#!/bin/sh

#  KEEP THIS FILE IN FOLDER CNC/dataForPeaks/

rootDownload="/home/KAUST/alamt/CNC/dataForPeaks/"
cd $rootDownload

foldName=ARI3A
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*ARID3A*Peak.gz"

 cd $rootDownload


foldName=BATF
 mkdir $foldName
 cd $foldName
# wget --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*Batf*Peak.gz"

  cd $rootDownload
#
foldName=CEBPB
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*Cebpb*Peak.gz"

  cd $rootDownload

foldName=CEBPD
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*Cebpd*Peak.gz"

  cd $rootDownload


# ESRRA/ ERRAI
foldName=ESRRA
 mkdir $foldName
 cd $foldName                         
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*Erra*Peak.gz"

  cd $rootDownload

foldName=FOSL1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*FOSL1*Peak.gz"

  cd $rootDownload


foldName=FOSL2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*FOSL2*Peak.gz"

  cd $rootDownload


foldName=FOXA1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*FOXA1*Peak.gz"


  cd $rootDownload


foldName=FOXA2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*FOXA2*Peak.gz"


  cd $rootDownload

foldName=FOXM1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*FOXM1*Peak.gz"

  cd $rootDownload

foldName=FOXP2
 mkdir $foldName
 cd $foldName
 # wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*FOXP2*Peak.gz"

  cd $rootDownload

foldName=GATA1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*GATA1*Peak.gz"

  cd $rootDownload

foldName=GATA2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*GATA2*Peak.gz"

  cd $rootDownload

foldName=GATA3
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*GATA3*Peak.gz"

  cd $rootDownload
foldName=HNF4A
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*HNF4A*Peak.gz"


  cd $rootDownload
foldName=HSF1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*HSF1*Peak.gz"


  cd $rootDownload

foldName=IRF1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*IRF1*Peak.gz"


  cd $rootDownload

# IRF3
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*irf3*Peak.gz"


  cd $rootDownload


foldName=IRF4
 mkdir $foldName
 cd $foldName
# IRF4
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*irf4*Peak.gz"


  cd $rootDownload


foldName=JUN
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*CJUNi*Peak.gz"


  cd $rootDownload


foldName=JUNB
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*JUNb*Peak.gz"


  cd $rootDownload

foldName=JUND
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*JUNd*Peak.gz"


  cd $rootDownload

foldName=MEF2A
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*MEF2A*Peak.gz"

  cd $rootDownload


foldName=NFAC1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*NFATC1*Peak.gz"

  cd $rootDownload


foldName=NFE2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case   "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*NFE2*Peak.gz"

  cd $rootDownload



foldName=NR2C2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*TR4*Peak.gz"


  cd $rootDownload

foldName=COT2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*NR2F2*Peak.gz"


  cd $rootDownload


foldName=GCR
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*GRPCR*Peak.gz"


  cd $rootDownload


foldName=PO5F1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*pou5f1*Peak.gz"


  cd $rootDownload


foldName=PRDM1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*PRDM1*Peak.gz"


  cd $rootDownload




foldName=SPI1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*SP1*Peak.gz"


  cd $rootDownload



foldName=STAT1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*stat1*Peak.gz"


  cd $rootDownload


foldName=STAT2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*stat2*Peak.gz"

  cd $rootDownload


foldName=STAT3
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*stat3*Peak.gz"

  cd $rootDownload



foldName=STA5A
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*stat5a*Peak.gz"


  cd $rootDownload



foldName=TBP
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*TBP*Peak.gz"

  cd $rootDownload



foldName=TFE2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*TCF3*Peak.gz"


  cd $rootDownload


foldName=TF7L2
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*TCF7L2*Peak.gz"


  cd $rootDownload


foldName=ZEB1
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*ZEB1*Peak.gz"

  cd $rootDownload



foldName=ZN384
 mkdir $foldName
 cd $foldName
# wget  --ignore-case  "ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeAwgTfbsUniform/wgEncodeAwgTfbs*ZNF384*Peak.gz"

  cd $rootDownload




cd $rootDownload

for i in *
    do
		if test -d "$i"  #if dictionary
		then  
			echo "$i" ;                 
			 cd $rootDownload/$i;
			 #gunzip *.gz
			 rm allPeak.bed
			 #cat *Peak* > allPeak.bed
			 cd $rootDownload
		fi
    done

cd $rootDownload
