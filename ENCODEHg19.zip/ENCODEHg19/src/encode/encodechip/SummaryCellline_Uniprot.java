package encode.encodechip;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class SummaryCellline_Uniprot {

	String fnmTissueInfo;
	String foutSummaryCell_Uniprot;
	String foutSummaryTissue_Cell;




	public SummaryCellline_Uniprot(String fnmTissueInfo,
			String foutSummaryCell_Uniprot, String foutSummaryTissue_Cell) {
		super();
		this.fnmTissueInfo = fnmTissueInfo;
		this.foutSummaryCell_Uniprot = foutSummaryCell_Uniprot;
		this.foutSummaryTissue_Cell = foutSummaryTissue_Cell;
	}



	void doProcessing()
	{

		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmTissueInfo);
		String tmp[];
		String curFile, curCell, curTissue, curUniprot;


		StringBuffer bufCell_Uniprot = new StringBuffer();
		StringBuffer bufTissue_Cell  = new StringBuffer();


		LinkedHashMap<String, Set<String> >   lhm_cell_setTF = new LinkedHashMap<String, Set<String>>();
		LinkedHashMap<String, Set<String> >   lhm_tissue_setCell = new LinkedHashMap<String, Set<String>>();


		for(int i=0;  i<vectAll.size() ;i++)
		{

			tmp = ConstantValue.patTab.split( vectAll.get(i)  ) ;

			curCell = tmp[1];
			curTissue = tmp[3];
			curUniprot = tmp[2];

			if(lhm_cell_setTF.containsKey( curCell))
			{
				lhm_cell_setTF.get(curCell).add(curUniprot);
			}else
			{
				Set tmpSet = new LinkedHashSet<String>();
				tmpSet.add(curUniprot);
				lhm_cell_setTF.put(curCell, tmpSet);

			}


			if(lhm_tissue_setCell.containsKey( curTissue))
			{
				lhm_tissue_setCell.get(curTissue).add(curCell);
			}else
			{
				Set tmpSet = new LinkedHashSet<String>();
				tmpSet.add(curCell);
				lhm_tissue_setCell.put(curTissue, tmpSet);

			}


		}


		/*
		 *  Now Write
		 */


		 Set set = lhm_cell_setTF.entrySet();
		 System.out.println("Total Unique cell:" + set.size() ) ;
		 Iterator itr = set.iterator();
		 while(itr.hasNext()){


			 Map.Entry me = (Map.Entry) itr.next();
			 String cell = (String)me.getKey();
			 Set setTfObj = (Set) me.getValue();

			 
			 String[] arr = (String[]) setTfObj.toArray(new String[setTfObj.size()]);
			 int setSize = arr.length;
			 
			 bufCell_Uniprot.append(cell +"\t" + setSize + "\t");

			 
			 for(int c=0; c<setSize;c++)
			 {
				 if(c==setSize-1)
					 bufCell_Uniprot.append(arr[c]+"\n");
				 else
					 bufCell_Uniprot.append(arr[c]+  ConstantValue.Seperator_Comma);
			 }


		 }


		 
		 /*
			 *  Now Write
			 */


			 set = lhm_tissue_setCell.entrySet();
			 System.out.println("Total Unique tissue:" + set.size() ) ;
			 itr = set.iterator();
			 while(itr.hasNext()){


				 Map.Entry me = (Map.Entry) itr.next();
				 String tissue = (String)me.getKey();
				 Set setCellObj = (Set) me.getValue();

				 
				 String[] arr = (String[]) setCellObj.toArray(new String[setCellObj.size()]);
				 int setSize = arr.length;
				 
				 bufTissue_Cell.append(tissue +"\t" + setSize + "\t");

				 
				 for(int c=0; c<setSize;c++)
				 {
					 if(c==setSize-1)
						 bufTissue_Cell.append(arr[c]+"\n");
					 else
						 bufTissue_Cell.append(arr[c]+ ConstantValue.Seperator_Comma);
				 }

				 

			 }
		 

		 CommonFunction.writeContentToFile(this.foutSummaryCell_Uniprot, bufCell_Uniprot +"");
		 CommonFunction.writeContentToFile(this.foutSummaryTissue_Cell,  bufTissue_Cell  +"");
	}

	public static void main(String[] args) {

		//		SummaryCellline_Uniprot obj = new SummaryCellline_Uniprot(args[0], args[1], args[2]);

		SummaryCellline_Uniprot obj = new SummaryCellline_Uniprot("EncodeChip_FileNames_CellLine_TFNamesUNIPROT_Tissue_Hg19.txt", 
				"Summary_Cellline_Uniprot.txt", 
				"Summary_Tissue_Cellline.txt");



		obj.doProcessing();
	}



}
