package encode.encodechip;


import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;
import encode.folderoperation.FolderOperations;

public class CopyPaste_File_UniprotBasis {


	String fnmList;
	String sourceFold;
	String destFold;

	Vector<String> vectFileNames = new Vector<String>();

	public CopyPaste_File_UniprotBasis(String fnmList, String sourceFold,
			String destFold) {
		super();
		this.fnmList = fnmList;
		this.sourceFold = sourceFold;
		this.destFold = destFold;
	}

	void loadFileName_Foldname()
	{
		vectFileNames = CommonFunction.readlinesOfAfile(this.fnmList);
	}


	void doCopyPaste()
	{
		String curLine;
		String tmp[];

		String curFileName , curUniprotName;

		String curSrcFullPath, curDestFullPath , curDestFoldFullPath;

		FolderOperations.create_new_folder(this.destFold);
		for(int i=0; i<vectFileNames.size() ;i++)
		{
			curLine = vectFileNames.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curLine);

			curFileName = tmp[0];
			curUniprotName = tmp[2];

			curDestFoldFullPath = this.destFold+ 	curUniprotName ;

			curSrcFullPath =  this.sourceFold +  curFileName ;
			curDestFullPath = curDestFoldFullPath + "/" + curFileName ;  




			//			// Create the folder if it does not exist
						FolderOperations.create_new_folder(curDestFoldFullPath);
			//			
			//			// copy-paste the file into new folder 
						FolderOperations.copy_paste_file(curSrcFullPath, curDestFullPath);

		}
	}

	void doProcessing()
	{
		loadFileName_Foldname();
		doCopyPaste();



	}

	public static void main(String[] args) {

		CopyPaste_File_UniprotBasis obj = new CopyPaste_File_UniprotBasis(args[0], args[1], args[2]);

//		CopyPaste_File_UniprotBasis obj = new CopyPaste_File_UniprotBasis("./Encode_FileNames_UNIPROT.txt", "./sourceChip/", "./tanvir/"); 


		obj.doProcessing();

	}

}
