package encode.encodechip;

import java.util.Vector;

import encode.common.CommonFunction;

/*
 * 
 * Paper :Sequence features and chromatin structure around the genomic regions bound by 119 human transcription factors
 * PMID:
 * 
 * 
 *  Covert Encode Chipseq Filename -> TF name
 *  Basic algo:
 *  file name pattern
 *   wgEncodeAwgTfbsBroadDnd41CtcfUniPk.narrowPeak.gz
 *   wgEncodeAwgTfbsUwWi38CtcfUniPk.narrowPeak.gz
 *  
 *  1. wgEncodeAwgTbs , then
 *  2. LibraryNames  starts with Capital Letter (e.g. Broad) , then
 *  3. Cell Line starts with Capital Letter (e.g. Dnd41) ,  then
 *  4. TF name starts with Capital Letter (Ctcf ) , then
 *  5. Unipk. , then
 *  6. some other narrow.gz or otehr
 *  
 *  
 *  So, 4th pattern is the TF name, If we choose letters between (6th Capital Letter to before of 7th Capital Letter)
 *  then we will get the TF name
 */
public class Encode_Filename_TFname_mm9 {

	String encodeFilename="Encode_FileNames_mm9.txt";
	String encodeTFname="EEncode_FileNames_TFNames_mm9.txt";
	
	
	void init(String fnmeChip, String fnmTF)
	{
		this.encodeFilename=fnmeChip;
		this.encodeTFname=fnmTF;
	}
	
	void doProcessing()
	{
		Vector<String> vectFileName = CommonFunction.readlinesOfAfile(this.encodeFilename);
		StringBuffer resBuffer = new StringBuffer();
		
		String curFileName;
		String cutFactor;
		int curLen;
		
		int capitalStart=5;
		int capitalEnd=6;
		
		int totCapitalFound=0;
		int indexStart=0;
		int indexEnd=0;
		
		
		
		for(int i=0; i<vectFileName.size();i++)
		{
			curFileName = vectFileName.get(i);
			//  wgEncodeAwgTfbsBroadDnd41CtcfUniPk.narrowPeak.gz
			//    *     *  *   *    *    *---*
			curLen = curFileName.length();
			totCapitalFound=0;
			
			for(int j=0; j<curLen;j++)
			{
				if( Character.isUpperCase(curFileName.charAt(j) ) )
				{
					totCapitalFound ++;
					
					if(totCapitalFound==capitalStart)
					{
						indexStart = j;
					}
					
					if(totCapitalFound==capitalEnd)
					{
						indexEnd = j;
						// break;
					}
					
				}
			}
			
			resBuffer.append( curFileName+"\t" + curFileName.substring(indexStart, indexEnd) + "\n");
			//  The TF entrez name is between 6th and 7th star/Capital Letter
			
			
		}
		
		CommonFunction.writeContentToFile(this.encodeTFname, resBuffer+"");
	}
	
	public static void main(String[] args) {
		
		Encode_Filename_TFname_mm9 obj = new Encode_Filename_TFname_mm9();
		
		
		
//		obj.init("Encode_FileNames_mm9.txt", "Encode_FileNames_TFNames_mm9.txt");
		
		obj.init(args[0], args[1]);
		
		obj.doProcessing();
		
	}
	
}
