package encode.encodechip;



import java.util.Vector;

import encode.bean.Encode;
import encode.common.CommonFunction;


/*
 * 
 * Paper :Sequence features and chromatin structure around the genomic regions bound by 119 human transcription factors
 * PMID:
 * 
 * 
 *  Covert Encode Chipseq Filename -> TF name
 *  Basic algo:
 *  file name pattern
 *   wgEncodeAwgTfbsBroadDnd41CtcfUniPk.narrowPeak.gz
 *   wgEncodeAwgTfbsUwWi38CtcfUniPk.narrowPeak.gz
 *   wgEncodeUwTfbsRptecCtcfStdHotspotsRep1.broadPeak
 *  
 *  1. wgEncodeAwgTbs , then
 *  2. LibraryNames  starts with Capital Letter (e.g. Broad) , then
 *  3. Cell Line starts with Capital Letter (e.g. Dnd41) ,  then
 *  4. TF name starts with Capital Letter (Ctcf ) , then
 *  5. Unipk. , then
 *  6. some other narrow.gz or otehr
 *  
 *  
 *  So, 4th pattern is the TF name, If we choose letters between (6th Capital Letter to before of 7th Capital Letter)
 *  then we will get the TF name
 */
public class Encode_Filename_CellLine_TFname_hg19 {

	String encodeFilename="Encode_FileNames_mm9.txt";
	String encodeTFname="EEncode_FileNames_TFNames_mm9.txt";
	
	
	void init(String fnmeChip, String fnmTF)
	{
		this.encodeFilename=fnmeChip;
		this.encodeTFname=fnmTF;
	}
	
	void doProcessing()
	{
		Vector<String> vectFileName = CommonFunction.readlinesOfAfile(this.encodeFilename);
		StringBuffer resBuffer = new StringBuffer();
		
		String curFileName;
		
		
		
		for(int i=0; i<vectFileName.size();i++)
		{
			curFileName = vectFileName.get(i);
			Encode enc = CommonFunction.get_cellline_tfname_FromFileName(curFileName);
			
			resBuffer.append( curFileName+"\t" + enc.getCellline() + "\t" + enc.getTfname() + "\n");
			
			
		}
		
		CommonFunction.writeContentToFile(this.encodeTFname, resBuffer+"");
	}
	
	
	

	
	
	
	
	public static void main(String[] args) {
		
		Encode_Filename_CellLine_TFname_hg19 obj = new Encode_Filename_CellLine_TFname_hg19();
		
		
		
//		obj.init("Encode_FileNames_Hg19.txt", "Encode_FileNames_CellLine_TFNames_Hg19.txt");
		
		obj.init(args[0], args[1]);
		
		obj.doProcessing();
		
	}
	
}
