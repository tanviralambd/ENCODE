package encode.encodechip;

import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class SelectSubRegion_FromSummit {

	
	String fnmIn="tmp.txt";
	String fnmOut="tmp.out";
	
	int peakUpstream, peakDownstream;
	
	
	
	void doProcessing()
	{
		String curDesc="" , curLine ;
		String tmp[] ;
		StringBuffer resBuf = new StringBuffer();
		int start,end, summitRel, summit, finalStart, finalEnd;
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmIn) ;
		
		for(int i=0; i<vectAll.size();i++)
		{
			curLine = vectAll.get(i);
			tmp = ConstantValue.patWhiteSpace.split(curLine);
			

			
			if(tmp.length ==10)
			{
				
				start = Integer.parseInt( tmp[1]);
				end = Integer.parseInt(  tmp[2]);
				
				summitRel = Integer.parseInt( tmp[9] ) ;
				summit = start + summitRel;
				
				finalStart = (summit - peakUpstream )   > start ?  (summit - peakUpstream ) : start;
				finalEnd   = (summit + peakDownstream ) > end   ?   end                     : (summit + peakDownstream ) ;
				
				curDesc = tmp[0] + "\t" + finalStart + "\t" + finalEnd + "\t" +
						tmp[3] + "\t" +tmp[4] + "\t" + tmp[5] + "\n";  
				
//				System.out.println("narrowPeak");
			}else if(tmp.length==9)
			{
				
				curDesc = tmp[0] + "\t" + tmp[1] + "\t" + tmp[2] + "\t" +
						tmp[3] + "\t" +tmp[4] + "\t" + tmp[5] + "\n";  
//				System.out.println("broadPeak");
			}
			
			resBuf.append(curDesc +"");
			
		}
		
		
		CommonFunction.writeContentToFile(this.fnmOut, resBuf+"");
		
	}
	
	
	
	public SelectSubRegion_FromSummit(String fnmIn, String fnmOut,
			int peakUpstream, int peakDownstream) {
		super();
		this.fnmIn = fnmIn;
		this.fnmOut = fnmOut;
		this.peakUpstream = peakUpstream;
		this.peakDownstream = peakDownstream;
	}



	public static void main(String[] args) {
	
		SelectSubRegion_FromSummit obj = new SelectSubRegion_FromSummit(args[0] ,args[1] , Integer.parseInt(args[2]), Integer.parseInt(args[3])   );
		
//		SelectSubRegion_FromSummit obj = new SelectSubRegion_FromSummit( "tmp.txt" , "tmp.out", Integer.parseInt( "100"), Integer.parseInt( "100")  );
		obj.doProcessing();
		
	}
	
	
}
