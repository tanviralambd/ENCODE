package encode.encodechip;

import java.util.Vector;

import encode.common.CommonFunction;
import encode.folderoperation.FolderOperations;

public class MergeChipResults {

	
	
	String inputFold;
	String outResult;
	
	
	void init()
	{
		
	}
	
	void doProcessing()
	{
		
		Vector<String > allFileNames = FolderOperations.listFiles_Files_Dir( this.inputFold);
		for(int i=0; i<allFileNames.size();i++)
		{
			
		}
		
	}
	
	double[] getValueofFromAfile(String fileName)
	{
		double res [] = new double [5];
		
		return res;
	}
	
	
	public static void main(String[] args) {
		
		
		
	}
	
	
}
