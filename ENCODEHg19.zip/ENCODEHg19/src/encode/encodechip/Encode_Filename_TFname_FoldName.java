package encode.encodechip;

import java.util.LinkedHashMap;
import java.util.Vector;

import encode.common.CommonFunction;

public class Encode_Filename_TFname_FoldName {

	
	String fnm_Filename_Tfname;
	String fnm_Tfname_Hocomoco;
	
	String fnm_Filename_Hocomoco;
	
	
	LinkedHashMap<String, String > lhm_Filename_Tfname = new LinkedHashMap<String, String>();
	
	LinkedHashMap<String, String > lhm_Tfname_Uniprot = new LinkedHashMap<String, String>();
	Vector<String> result = new Vector<String>();
	
	void load_Values()
	{
		
		lhm_Filename_Tfname = CommonFunction.readlinesOfAfile_asMap(this.fnm_Filename_Tfname, 0, 1);
		lhm_Tfname_Uniprot = CommonFunction.readlinesOfAfile_asMap(this.fnm_Tfname_Hocomoco, 0, 1);
		
	}
	
	void jonTwoTable()
	{
		result = CommonFunction.joinMapaValue_MapbKey(lhm_Filename_Tfname, lhm_Tfname_Uniprot);
		
		
	}
	
	void writeResult()
	{
		StringBuffer bufResult = new StringBuffer();
		for(int i=0; i<result.size();i++)
		{
			bufResult.append(result.get(i) + "\n");
		}
		
		
		CommonFunction.writeContentToFile(this.fnm_Filename_Hocomoco, bufResult+"");
	}
	
	
	public Encode_Filename_TFname_FoldName(String fnm_Filename_Tfname,
			String fnm_Tfname_Hocomoco, String fnm_Filename_Hocomoco) {
		super();
		this.fnm_Filename_Tfname = fnm_Filename_Tfname;
		this.fnm_Tfname_Hocomoco = fnm_Tfname_Hocomoco;
		this.fnm_Filename_Hocomoco = fnm_Filename_Hocomoco;
	}





	void doProcessing()
	{
		load_Values();
		jonTwoTable();
		writeResult();
	}
	
	public static void main(String[] args) {
		
//		Encode_Filename_TFname_FoldName obj = new Encode_Filename_TFname_FoldName("Encode_FileNames_TFNames.txt","Encode_TFNames_HOCOMOCO.txt", "Encode_FileNames_UNIPROT.txt"); 
		
		
		Encode_Filename_TFname_FoldName obj = new Encode_Filename_TFname_FoldName(args[0],args[1] , args[2]); 
		
		
		obj.doProcessing();
		
	}
	
}
