package encode.encodechip;

import java.util.LinkedHashMap;
import java.util.Vector;
import encode.bean.Encode;
import encode.common.CommonFunction;
import encode.constant.ConstantValue;
import encode.folderoperation.FolderOperations;

public class Rename4thColumn {

	
	String fnmFileName_CellLine_Uniprot;
	String foldIn;
	String foldOut;
	
	
	LinkedHashMap<String, Encode> lhm_filename_encObbj = new LinkedHashMap<String, Encode>();
	
	public Rename4thColumn(String fnmFileName_CellLine_Uniprot, String foldIn,
			String foldOut) {
		super();
		this.fnmFileName_CellLine_Uniprot = fnmFileName_CellLine_Uniprot;
		this.foldIn = foldIn;
		this.foldOut = foldOut;
	}


	void loadFilename_cellline_uniprotname()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmFileName_CellLine_Uniprot);
		String tmp[];
		for(int i=0; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			Encode tmpEnc = new Encode();
			tmpEnc.setCellline(tmp[1]);
			tmpEnc.setTfname(tmp[2]);
			
			lhm_filename_encObbj.put(tmp[0], tmpEnc);
			
			
		}
	}
	
	
	void rename_copypaste()
	{
		Vector<String> vectFname = FolderOperations.listFiles_Files_Dir(this.foldIn);
		StringBuffer result = new StringBuffer();
		
		FolderOperations.create_new_folder(this.foldOut+"/");
		
		// Now change the 4th column
		String tmp[];
		String curFilename,curCellLine, curUniprot;
		for(int i=0; i<vectFname.size();i++)
		{
			result = null;
			result = new StringBuffer();
			
			curFilename = vectFname.get(i);
			curCellLine = ((Encode)lhm_filename_encObbj.get(curFilename)).getCellline();
			curUniprot = ((Encode)lhm_filename_encObbj.get(curFilename)).getTfname();
			
			
			
			Vector<String> fileContent = CommonFunction.readlinesOfAfile( this.foldIn+ curFilename);
			for(int line=0; line<fileContent.size();line++)
			{
				tmp = ConstantValue.patTab.split( fileContent.get(line));
				
				result.append(
						tmp[0] + "\t"  +
						tmp[1] + "\t"  +
						tmp[2] + "\t"  +
						(curCellLine+":"+curUniprot) + "\t"  +
						tmp[4] + "\t"  +
						tmp[5] + "\n"  );
				
				
			}
			
			// Write one file with renamed name
			System.out.println("Writing in file: " + this.foldOut+vectFname.get(i) );
			CommonFunction.writeContentToFile(this.foldOut+vectFname.get(i), result+"");
		}
		
	
	}
	
	
	void doProcessing()
	{
		loadFilename_cellline_uniprotname();
		
		rename_copypaste();
		
	}
	
	public static void main(String[] args) {
		
		Rename4thColumn obj = new Rename4thColumn(args[0], args[1], args[2]);
		
//		Rename4thColumn obj = new Rename4thColumn("Encode_FileNames_CellLine_TFNamesUNIPROT_Tissue_Hg19.txt", 
//				"./infold/", 
//				"./outfold/");
		
		
		obj.doProcessing();
		
	}
}
