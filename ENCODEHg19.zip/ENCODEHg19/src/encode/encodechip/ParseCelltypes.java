package encode.encodechip;

import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class ParseCelltypes {

	
	String fnmEncodeHtml;
	String foutCelllines;
	
	public ParseCelltypes(String fnmEncodeHtml, String foutCelllines) {
		super();
		this.fnmEncodeHtml = fnmEncodeHtml;
		this.foutCelllines = foutCelllines;
	}


	String removeHTMLtag(String inp)
	{
		String result="";//  <TD>WI-38</TD>
		
		int start = inp.indexOf('>');
		int end = inp.indexOf('/');
		
		result = inp.substring( (start+1) , (end-1));
		
		if(result.startsWith("&"))
		{
			result=ConstantValue.noneStr;
		}
		
		return result;
	}
	
	void doProcessing()
	{
		
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmEncodeHtml);
		StringBuffer result = new StringBuffer();
		
		
		String curLine;
		String curCell,curTier, curDescription;
		String curLineage, curTissue, curKaryoType;
		
		for(int i=0; i<vectAll.size();i++)
		{
			curLine = vectAll.get(i);
			if(curLine.startsWith("<TR>"))
			{
				curCell = vectAll.get(i+1);
				curTier = vectAll.get(i+2);
				curDescription = vectAll.get(i+3);
				
				curLineage = vectAll.get(i+4);
				curTissue = vectAll.get(i+5);
				curKaryoType = vectAll.get(i+6);
				
				result.append(removeHTMLtag(curCell.toUpperCase()) + "\t" +
						removeHTMLtag(curTissue) + "\t" +
						removeHTMLtag(curKaryoType) + "\t" + 
						removeHTMLtag(curLineage) + "\t" +
						removeHTMLtag(curTier) + "\t" + 
						removeHTMLtag(curDescription) + "\t" + 
						
						"\n") ;
				
			}
			
			
		}
		
		
		CommonFunction.writeContentToFile(this.foutCelllines, result+"");
		
	}
	
	
	public static void main(String[] args) {
		
		ParseCelltypes obj = new ParseCelltypes(args[0] , args[1]);
		
//		ParseCelltypes obj = new ParseCelltypes("Cellines_Hg19.html", "Cellines_Hg19.txt") ;
		
		
		obj.doProcessing();
	}
	
}
