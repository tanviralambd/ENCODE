package encode.encodechip;

import java.util.LinkedHashMap;
import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class Encode_ReplaceByUniprot {

	String fnmFile_Cell_TF="EncodeChip_FileNames_CellLine_TFNames_Hg19.txt";
	String fnmTF_UniprotRepository="ENCODEChip_UNIPROT_hg19.txt";
	
	String fout="EncodeChip_FileNames_CellLine_TFNamesUNIPROT_Hg19.txt";
	
	
	LinkedHashMap<String, String> lhm_TFname_TFUniprot = new LinkedHashMap<String, String>();
	
	void loadRepository_EncodeTFname_Uniprot()
	{
		lhm_TFname_TFUniprot = CommonFunction.readlinesOfAfile_asMap(this.fnmTF_UniprotRepository, 0, 1);
		
		System.out.println("Total Unique tF name: " + lhm_TFname_TFUniprot.size());
		
	}
	
	
	void replaceByUniprot()
	{
		
		Vector<String> vectList_FileName_Cell_Tf = CommonFunction.readlinesOfAfile(this.fnmFile_Cell_TF);
		
		StringBuffer res = new StringBuffer();
		
		String fileName,cellName;
		String tfName , tfNameUniprot;
		
		String tmp[];
		
		for(int i=0; i<vectList_FileName_Cell_Tf.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectList_FileName_Cell_Tf.get(i));
			
			fileName = tmp[0];
			cellName = tmp[1];
			tfName = tmp[2];
			if(lhm_TFname_TFUniprot.containsKey(tfName))
			{
				tfNameUniprot = lhm_TFname_TFUniprot.get(tfName);
			}else
			{
				
				tfNameUniprot = "None";
			}
			
			res.append(fileName + "\t" + cellName + "\t" + tfNameUniprot  + "\n");
		}
		
		CommonFunction.writeContentToFile(this.fout, res + "");
		
	}
	
	
	void doProcessing()
	{
		loadRepository_EncodeTFname_Uniprot();
		
		replaceByUniprot();
		
	}
	
	
	
	
	public Encode_ReplaceByUniprot(String fnmFile_Cell_TF,
			String fnmTF_UniprotRepository, String fout) {
		super();
		this.fnmFile_Cell_TF = fnmFile_Cell_TF;
		this.fnmTF_UniprotRepository = fnmTF_UniprotRepository;
		this.fout = fout;
	}


	public static void main(String[] args) {
	
		Encode_ReplaceByUniprot obj = new Encode_ReplaceByUniprot( args[0], args[1], args[2]);
		
		obj.doProcessing();
		
		
	}
	
}
