package encode.resultAnalysis;

import java.util.Vector;

import javax.sql.CommonDataSource;

import encode.common.CommonFunction;
import encode.folderoperation.FolderOperations;

/*
 *  Read all files in a folder and combine reports from each file into as single file
 */
public class CallFolderWiseOverlap {

	String foldName;
	String ext;
	int upStreamFromSummit,  downStreamFromSummit;
	int tfbslen=1;
	String fnmOut;





	public CallFolderWiseOverlap(String foldName, String ext,
			int upStreamFromSummit, int downStreamFromSummit, String fnmOut, int tfbslen) {
		super();
		this.foldName = foldName+"/";
		this.ext = ext;
		this.upStreamFromSummit = upStreamFromSummit;
		this.downStreamFromSummit = downStreamFromSummit;
		this.fnmOut = fnmOut;
		this.tfbslen = tfbslen;
		
		System.out.println("********* searching in **************** "+ this.foldName);
	}

	void doProcessing()
	{

		Vector<String> vectFnames = FolderOperations.listFiles_Files_Dir(this.foldName);

		StringBuffer finalOutput = new StringBuffer();
		String curResult;
		for(int i=0; i<vectFnames.size();i++)
		{
//			System.out.println( vectFnames.get(i) );
			if(vectFnames.get(i).endsWith(this.ext)){
				CheckOverlapFromSummit obj1file = new CheckOverlapFromSummit( this.foldName+ vectFnames.get(i), "", 
						this.upStreamFromSummit, this.downStreamFromSummit , this.tfbslen);
				curResult = obj1file.doProcessing();
//				System.out.println( "Final Result: " + curResult );
				finalOutput.append(curResult + "\n");

			}
		}

		CommonFunction.writeContentToFile(this.fnmOut, finalOutput+"");

	}

	public static void main(String[] args) {

//		CallFolderWiseOverlap obj = new CallFolderWiseOverlap("./", "_MOUSE", Integer.parseInt("100"), Integer.parseInt("100") ,  "F9_RA_Sox17.bed.FOSL1_MOUSE.exist");

		CallFolderWiseOverlap obj = new CallFolderWiseOverlap(args[0], args[1], Integer.parseInt(args[2]), Integer.parseInt(args[3] ) ,
				args[4] , Integer.parseInt(args[5]));

		obj.doProcessing();

	}
}
