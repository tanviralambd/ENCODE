package encode.resultAnalysis;

import java.util.Vector;

import javax.sql.CommonDataSource;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.MaximizeAction;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

/*
 *  Check the overlap of of (mid point based summit in promoter) & (chip)
 *  If the overlap is N bp then it is a hit.
 */
public class CheckOverlapFromSummit {

	
	String inputFromBedtools;
	
	String output;
	
	int upStreamFromSummit;
	int downStreamFromSummit;
	int minOverlapBP=1;
	
	Vector<String> vectAllLines = new Vector<String>();
	
	public CheckOverlapFromSummit(String inputFromBedtools, String output,
			int upStreamFromSummit, int downStreamFromSummit, int minOverlapBP) {
		super();
		this.inputFromBedtools = inputFromBedtools;
		this.output = output;
		this.upStreamFromSummit = upStreamFromSummit;
		this.downStreamFromSummit = downStreamFromSummit;
		this.minOverlapBP = minOverlapBP;
	}

	void loadFiles()
	{
		vectAllLines = CommonFunction.readlinesOfAfile(this.inputFromBedtools);
	}
	
	int checkSummitSurrounding()
	{
		
		String tmp[];
		int startFirst, endFirst, startSecond, endSecond;
		
		int midFirst=0, peakStart=0 , peakEnd=0;
		int midSecond=0, peakStart2nd=0 , peakEnd2nd=0;
		
		boolean found =false;
		int foundOverlapLen=-1;
		
		int countNoOverlapHit=0;
		
		for(int i=0;i<vectAllLines.size();i++)
		{
			
			tmp = ConstantValue.patWhiteSpace.split(vectAllLines.get(i));
			
			startFirst = Integer.parseInt(tmp[1]);
			endFirst = Integer.parseInt(tmp[2]);
			
			midFirst = (int) Math.ceil( (startFirst+ endFirst)/2  );
			peakStart = midFirst  - this.upStreamFromSummit;
			peakEnd   = midFirst  + this.downStreamFromSummit;
			
			// 
			startSecond = Integer.parseInt(tmp[4]);
			endSecond  = Integer.parseInt(tmp[5]);
			peakStart2nd = startSecond ;  
			peakEnd2nd=endSecond;
			
//			midSecond = (int) Math.ceil( (startSecond+ endSecond)/2  );
//			peakStart2nd = Math.max( midSecond  - this.upStreamFromSummit    , startSecond  );
//			peakEnd2nd   = Math.min( midSecond  + this.downStreamFromSummit  , endSecond );
			
			
			// 1 bp
//			found = CommonFunction.isOverlap(peakStart	, peakEnd, peakStart2nd, peakEnd2nd);
//			
//			if(found)
//			{
//				countNoOverlapHit++;
//				
////				System.out.println(vectAllLines.get(i)) ;
//			}
			
			foundOverlapLen = CommonFunction.overlapCountBp (peakStart	, peakEnd, peakStart2nd, peakEnd2nd);
			
			if(foundOverlapLen> this.minOverlapBP)
			{
				countNoOverlapHit++;
				
//				System.out.println(vectAllLines.get(i)) ;
			}
			
			
		}
		
		
		return countNoOverlapHit;
	}
	
	String doProcessing()
	{
		loadFiles();
		int noOverlapHit = checkSummitSurrounding();
		String resultLine=  this.inputFromBedtools.substring(this.inputFromBedtools.lastIndexOf('.') +1  ) + "\t" + noOverlapHit ;
//		System.out.println(resultLine);
		return resultLine;
		
	}
	
	public static void main(String[] args) {
		
		CheckOverlapFromSummit obj = new CheckOverlapFromSummit("F9_RA_Sox17.bed.FOSL1_MOUSE", "F9_RA_Sox17.bed.FOSL1_MOUSE.exist", Integer.parseInt("100"), Integer.parseInt("100"),
				Integer.parseInt("10"));
//		
		
//		CheckOverlapFromSummit obj = new CheckOverlapFromSummit("tmp.FOSL1_MOUSE", "tmp.FOSL1_MOUSE.exist", Integer.parseInt("100"), Integer.parseInt("100"),
//				Integer.parseInt("205"));
		
		
		System.out.println( obj.doProcessing() );
	}
	
}
