package encode.mapCellLineFromREADME;



import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class ExtractInfoFromREADME_CAGE {

	
	String fnmREADME;
	String fnmOut;
	
	
	
	
	
	public ExtractInfoFromREADME_CAGE(String fnmREADME, String fnmOut) {
		super();
		this.fnmREADME = fnmREADME;
		this.fnmOut = fnmOut;
	}


	void doProcessing()
	{
		
		Vector<String> vectInput = CommonFunction.readlinesOfAfile(this.fnmREADME);
		StringBuffer res = new StringBuffer();
		
		String tmp[],tmpCSV[];
		
		String curFileName, curDetails, curCellline="",curTF="";
		
		for(int i=0 ; i<vectInput.size(); i++)
		{
			tmp = ConstantValue.patTab.split(vectInput.get(i));
			
			curFileName = tmp[0];
			curDetails  = tmp[1];
			
			if(curFileName.endsWith(".gz"))
			{
				
				int ind = curFileName.lastIndexOf('.');
				curFileName = curFileName.substring(0, ind);
						
			}
			
			
			tmpCSV = ConstantValue.patSemiColon.split(curDetails);
			for( int c=0 ; c<tmpCSV.length;c++)
			{
				tmpCSV[c] = tmpCSV[c].trim();
				if(tmpCSV[c].startsWith("cell="))
				{
					curCellline = tmpCSV[c];
					int ind = curCellline.indexOf('=');
					curCellline = curCellline.substring(ind+1);
					
				}
				
				
			}
			
			
			res.append(curFileName + "\t" + curCellline   + "\n");
		}
		
		
		CommonFunction.writeContentToFile(this.fnmOut, res+"");
		
	}
	
	
	public static void main(String[] args) {
//		
//		ExtractInfoFromREADME_CAGE obj = new ExtractInfoFromREADME_CAGE("wgEncodeRikenCage_cellline.txt", 
//				"wgEncodeRikenCage_FileName_Cellline.txt");
		

		ExtractInfoFromREADME_CAGE obj = new ExtractInfoFromREADME_CAGE(args[0] , args[1]);
		obj.doProcessing();
		
	}
	
	
}

