package encode.mapCellLineFromREADME;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class Common_CellIine_Dnase_ChIP_CAGE {




	String fnmDNASESample="wgEncodeAwgDnaseMasterSources_Tissue.tab";
	String fnmChIPSample="Encode_FileNames_CellLine_TFNamesUNIPROT_Tissue_Hg19.txt";
	String fnmCAGESample="EncodeCage_FileNames_CellLine_Tissue_Hg19.txt";

	String fnmOut = "mappingCellline_dnase_chip.txt";

	Set<String> setCellline_dnase = new LinkedHashSet<String>();
	Set<String> setCellline_chip  = new LinkedHashSet<String>();
	Set<String> setCellline_cage  = new LinkedHashSet<String>();


	Vector<String> vectCellline_dnase = new Vector<String>();
	Vector<String> vectCellline_chip  = new Vector<String>();
	Vector<String> vectCellline_cage  = new Vector<String>();


	void loadSampleInfoAsVector()
	{

		String tmp[];
		Vector<String> vectTmp;
		Set<String> setTmp;
		Iterator itr;

		// DNAseI
		setTmp = new LinkedHashSet<String>();
		vectTmp = CommonFunction.readlinesOfAfile(this.fnmDNASESample);
		for(int i=0; i<vectTmp.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectTmp.get(i));
			setTmp.add(tmp[1]);
		}
		itr = setTmp.iterator();
		while( itr.hasNext())
		{
			vectCellline_dnase.add(  itr.next().toString() );
		}
		System.out.println("Total DNASE cell line found: " + vectCellline_dnase.size());


		// ChIP-seq
		setTmp = new LinkedHashSet<String>();
		vectTmp = CommonFunction.readlinesOfAfile(this.fnmChIPSample);
		for(int i=0; i<vectTmp.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectTmp.get(i));
			setTmp.add(tmp[1]);
		}
		itr = setTmp.iterator();
		while( itr.hasNext())
		{
			vectCellline_chip.add(  itr.next().toString() );
		}
		System.out.println("Total ChIP-seq cell line found: " + vectCellline_chip.size());




		// CAGE
		setTmp = new LinkedHashSet<String>();
		vectTmp = CommonFunction.readlinesOfAfile(this.fnmCAGESample);
		for(int i=0; i<vectTmp.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectTmp.get(i));
			setTmp.add(tmp[1]);
		}
		itr = setTmp.iterator();
		while( itr.hasNext())
		{
			vectCellline_cage.add(  itr.next().toString() );
		}
		System.out.println("Total CAGE cell line found: " + vectCellline_cage.size());

	}




	void loadCelllineInfoAsSet()
	{

		String tmp[];
		Vector<String> vectTmp;
		Set<String> setTmp;
		Iterator itr;

		setTmp = new LinkedHashSet<String>();


		// DNAseI

		setCellline_dnase = CommonFunction.readlinesOfAfileInSet(this.fnmDNASESample,1);
		System.out.println("Total DNASE cell line found: " + setCellline_dnase.size());


		// ChIP-seq
		setCellline_chip = CommonFunction.readlinesOfAfileInSet(this.fnmChIPSample,1);
		System.out.println("Total ChIP-seq cell line found: " + setCellline_chip.size());



		// CAGE

		setCellline_cage = CommonFunction.readlinesOfAfileInSet(this.fnmCAGESample,1);
		System.out.println("Total CAGE cell line found: " + setCellline_cage.size());


		Set intersection_Dn_Ch = new HashSet(setCellline_dnase);
		intersection_Dn_Ch.retainAll(setCellline_chip);
		System.out.println("Common cellline: DNASE && ChIP  : " + intersection_Dn_Ch.size());


		Set intersection_Dn_CA = new HashSet(setCellline_dnase);
		intersection_Dn_CA.retainAll(setCellline_cage);
		System.out.println("Common cellline: DNASE && CAGE  : " + intersection_Dn_CA.size());


		Set intersection_Ch_CA = new HashSet(setCellline_chip);
		intersection_Ch_CA.retainAll(setCellline_cage);
		System.out.println("Common cellline: ChIP && CAGE  : " + intersection_Ch_CA.size());


		Set intersection_Dn_Ch_CA = new HashSet(setCellline_dnase);
		intersection_Dn_Ch_CA.retainAll(setCellline_chip);
		intersection_Dn_Ch_CA.retainAll(setCellline_cage);
		System.out.println("Common cellline: DNASE && ChIP && CAGE : " + intersection_Dn_Ch_CA.size());




		Iterator itrAll = intersection_Dn_Ch_CA.iterator();
		while( itrAll.hasNext())
		{
			System.out.print(  itrAll.next()+"," );
		}



	}


	
	void loadTissueInfoAsSet()
	{

		String tmp[];
		Vector<String> vectTmp;
		Set<String> setTmp;
		Iterator itr;

		setTmp = new LinkedHashSet<String>();


		// DNAseI

		setCellline_dnase = CommonFunction.readlinesOfAfileInSet(this.fnmDNASESample,2);
		System.out.println("Total DNASE tissue found: " + setCellline_dnase.size());


		// ChIP-seq
		setCellline_chip = CommonFunction.readlinesOfAfileInSet(this.fnmChIPSample,3);
		System.out.println("Total ChIP-seq tissue found: " + setCellline_chip.size());



		// CAGE

		setCellline_cage = CommonFunction.readlinesOfAfileInSet(this.fnmCAGESample,2);
		System.out.println("Total CAGE tissue found: " + setCellline_cage.size());


		Set intersection_Dn_Ch = new HashSet(setCellline_dnase);
		intersection_Dn_Ch.retainAll(setCellline_chip);
		System.out.println("Common tissue: DNASE && ChIP  : " + intersection_Dn_Ch.size());


		Set intersection_Dn_CA = new HashSet(setCellline_dnase);
		intersection_Dn_CA.retainAll(setCellline_cage);
		System.out.println("Common tissue: DNASE && CAGE  : " + intersection_Dn_CA.size());


		Set intersection_Ch_CA = new HashSet(setCellline_chip);
		intersection_Ch_CA.retainAll(setCellline_cage);
		System.out.println("Common tissue: ChIP && CAGE  : " + intersection_Ch_CA.size());


		Set intersection_Dn_Ch_CA = new HashSet(setCellline_dnase);
		intersection_Dn_Ch_CA.retainAll(setCellline_chip);
		intersection_Dn_Ch_CA.retainAll(setCellline_cage);
		System.out.println("Common tissue: DNASE && ChIP && CAGE : " + intersection_Dn_Ch_CA.size());


		
		
		Iterator itrAll = intersection_Dn_Ch_CA.iterator();
		while( itrAll.hasNext())
		{
			System.out.print(  itrAll.next()+"," );
		}
		

	}

	
	void findCommonCellLineAsvector()
	{
		String tmp[];
		StringBuffer resBuf = new StringBuffer(); 
		resBuf.append("Cellline_DNase"+"\t"+"Cellline_ChIPSeq"+"\n");

		String curDNASE,curCHIP;
		StringBuffer tmpBuf= new StringBuffer();

		for(int i=0; i<vectCellline_dnase.size();i++)
		{
			curDNASE = vectCellline_dnase.get(i).toUpperCase();

			for(int j=0 ; j<vectCellline_chip.size(); j++)
			{
				curCHIP = vectCellline_chip.get(j).toUpperCase();



				if(curDNASE.equalsIgnoreCase(curCHIP)) // 1. Exact match
				{
					resBuf.append(curDNASE+"\t"+curCHIP+"\n");


				}else // 2. Partial match (dnase: H1-hESC  chip: H1hESC )
				{
					tmp = ConstantValue.patHyphen.split(curDNASE);
					if(tmp.length>1)
					{
						tmpBuf = new StringBuffer();
						for(int m=0; m<tmp.length;m++)
						{
							tmpBuf.append(tmp[m]);
						}

						if( (tmpBuf.toString()).equals(curCHIP))
						{
							resBuf.append(curDNASE+"\t"+curCHIP+"\n");
						}

					}



				}





			}

		}


		CommonFunction.writeContentToFile(this.fnmOut, resBuf+"");
	}



	void doProcessing()
	{
		//		loadSampleInfoAsVector();
		//		
		//		findCommonCellLineAsvector();


		loadCelllineInfoAsSet();
		loadTissueInfoAsSet();

	}






	public Common_CellIine_Dnase_ChIP_CAGE(String fnmDNASESample,
			String fnmChIPSample, String fnmCAGESample, String fnmOut) {
		super();
		this.fnmDNASESample = fnmDNASESample;
		this.fnmChIPSample = fnmChIPSample;
		this.fnmCAGESample = fnmCAGESample;
		this.fnmOut = fnmOut;
	}


	public static void main(String[] args) {

		Common_CellIine_Dnase_ChIP_CAGE obj = new Common_CellIine_Dnase_ChIP_CAGE(
				"wgEncodeAwgDnaseMasterSources_Tissue.tab", 
				"EncodeChip_FileNames_CellLine_TFNamesUNIPROT_Tissue_Hg19.txt", 
				"EncodeCage_FileNames_CellLine_Tissue_Hg19.txt",
				"result.txt");

		obj.doProcessing();

	}

}
