package encode.mapCellLineFromREADME;

import java.util.LinkedHashMap;
import java.util.Vector;

import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class SubSelectFiles {

	
	String fin;
	String finDetails;
	String fout;
	
	
	
	public SubSelectFiles(String fin, String finDetails, String fout) {
		super();
		this.fin = fin;
		this.finDetails = finDetails;
		this.fout = fout;
	}


	void doProcessing()
	{
		
		Vector<String> myfiles = CommonFunction.readlinesOfAfile(this.fin);
		Vector<String> allFiles = CommonFunction.readlinesOfAfile(this.finDetails);
		
		LinkedHashMap<String, String> lhm_name_details = new LinkedHashMap<String, String>();
		String tmp[];
		String curFname;
		for(int i=0; i< allFiles.size();i++)
		{
			tmp = ConstantValue.patTab.split(allFiles.get(i));
			curFname = tmp[0];
			if( lhm_name_details.containsKey(curFname))
			{
				
			}else
			{
				lhm_name_details.put(curFname, allFiles.get(i));
			}
			
		}
		
		
		
		
		
		StringBuffer res = new StringBuffer(); 
		for( int i=0; i<myfiles.size(); i++)
		{
			curFname = myfiles.get(i);
			if(lhm_name_details.containsKey(curFname))
			{
				res.append(lhm_name_details.get(curFname) + "\n");
			}else
			{
				System.out.println( curFname  + "not found" );
			}
					
		}
		
		
		CommonFunction.writeContentToFile(this.fout, res+"");
		
	}

	public static void main(String[] args) {
		
		SubSelectFiles obj = new SubSelectFiles(args[0], args[1], args[2]);
//		SubSelectFiles obj = new SubSelectFiles("Encode_FileNames_Hg19.txt", 
//				"wgEncodeChipSeqMerged_FileName_Cellline_TF.txt", "tmp.out");
		obj.doProcessing();
		
	}
	
}
