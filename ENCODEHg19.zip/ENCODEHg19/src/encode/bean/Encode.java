package encode.bean;

public class Encode {


	String cellline;
	String tfname;
	public String getCellline() {
		return cellline;
	}
	public void setCellline(String cellline) {
		this.cellline = cellline;
	}
	public String getTfname() {
		return tfname;
	}
	public void setTfname(String tfname) {
		this.tfname = tfname;
	}
	
}
