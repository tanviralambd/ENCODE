package encode.bean;



public class CPG {

	String  cpgChrom;
	Integer cpgStart;
    Integer cpgEnd;


    
	public CPG(String cpgChrm, Integer cpgStart, Integer cpgEnd)
	{
		super();
		this.cpgChrom = cpgChrm;
		this.cpgStart = cpgStart;
		this.cpgEnd = cpgEnd;

	}



	public String getCpgChrom() {
		return cpgChrom;
	}



	public void setCpgChrom(String cpgChrom) {
		this.cpgChrom = cpgChrom;
	}



	public Integer getCpgStart() {
		return cpgStart;
	}



	public void setCpgStart(Integer cpgStart) {
		this.cpgStart = cpgStart;
	}



	public Integer getCpgEnd() {
		return cpgEnd;
	}



	public void setCpgEnd(Integer cpgEnd) {
		this.cpgEnd = cpgEnd;
	}
	
	

	
    
    
}
