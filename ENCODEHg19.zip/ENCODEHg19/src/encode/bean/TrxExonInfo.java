/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package encode.bean;


import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Pattern;

/**
 *
 * @author tanviralam
 */
public class TrxExonInfo {



	String chrom;
	int start;
	int end;
	String name;
	String score;
	String strand;
	int thickStart ; // CDS START
	int thickEnd; // CDS END
	String itemRGB;
	int   blockCount;
	Vector<Integer> blockSizes;
	Vector<Integer> blockStarts;

	Vector<Integer> exonStarts;
	Vector<Integer> exonEnds;

	String stringBlockSizes;
	String stringBlockStarts;

	int len; 
	int tss_0based;
	int translationIS_0based;


	int TU=-1;
	int myID=0;




	public TrxExonInfo(String chm,String st, String en,
			String name, String score,String strand,
			String thickStart,String thickEnd , String itemRGB,
			String blockCount,String blockSizes,String blockStarts ) {

		this.chrom = chm;
		this.start = Integer.parseInt(st);
		this.end = Integer.parseInt(en);


		this.strand = strand;
		this.len = this.end - this.start + 1 ;





		this.name = name;
		this.score = score;
		this.thickStart = Integer.parseInt(thickStart);
		this.thickEnd = Integer.parseInt(thickEnd);
		this.itemRGB = itemRGB;
		this.blockCount = Integer.parseInt(blockCount);

		this.stringBlockSizes = blockSizes;
		this.stringBlockStarts = blockStarts;
		this.blockSizes = new Vector<Integer>();
		this.blockStarts = new Vector<Integer>();


		StringTokenizer stringTokenizer = new StringTokenizer(blockSizes, ",");
		while (stringTokenizer.hasMoreElements()) {
			int val = Integer.parseInt(stringTokenizer.nextElement().toString() );
			this.blockSizes.add(val);          
		}


		stringTokenizer = new StringTokenizer(blockStarts, ",");
		while (stringTokenizer.hasMoreElements()) {
			int val = Integer.parseInt(stringTokenizer.nextElement().toString() );
			this.blockStarts.add(val);

		}

		int i=0;
		this.exonStarts = new Vector<Integer>();
		this.exonEnds = new Vector<Integer>();
		for(; i<this.blockCount;i++)
		{

			this.exonStarts.add(this.start + this.blockStarts.get(i)   ) ;
			this.exonEnds.add(  this.start + this.blockStarts.get(i)  + this.blockSizes.get(i) ) ;
		}


		if(strand.equals("+"))
		{
			tss_0based = this.start;
			translationIS_0based = this.thickStart;
		}else
		{
			tss_0based = this.end-1;
			translationIS_0based = this.thickEnd-1;
		}
		
	}

	public String getChrom() {
		return chrom;
	}





	public void setChrom(String chrom) {
		this.chrom = chrom;
	}





	public int getStart() {
		return start;
	}





	public void setStart(int start) {
		this.start = start;
	}





	public int getEnd() {
		return end;
	}





	public void setEnd(int end) {
		this.end = end;
	}





	public String getName() {
		return name;
	}





	public void setName(String name) {
		this.name = name;
	}





	public String getScore() {
		return score;
	}





	public void setScore(String score) {
		this.score = score;
	}





	public String getStrand() {
		return strand;
	}





	public void setStrand(String strand) {
		this.strand = strand;
	}





	public int getThickStart() {
		return thickStart;
	}





	public void setThickStart(int thickStart) {
		this.thickStart = thickStart;
	}





	public int getThickEnd() {
		return thickEnd;
	}





	public void setThickEnd(int thickEnd) {
		this.thickEnd = thickEnd;
	}





	public String getItemRGB() {
		return itemRGB;
	}





	public void setItemRGB(String itemRGB) {
		this.itemRGB = itemRGB;
	}





	public int getBlockCount() {
		return blockCount;
	}





	public void setBlockCount(int blockCount) {
		this.blockCount = blockCount;
	}





	public Vector<Integer> getBlockSizes() {
		return blockSizes;
	}





	public void setBlockSizes(Vector<Integer> blockSizes) {
		this.blockSizes = blockSizes;
	}





	public Vector<Integer> getBlockStarts() {
		return blockStarts;
	}





	public void setBlockStarts(Vector<Integer> blockStarts) {
		this.blockStarts = blockStarts;
	}





	public Vector<Integer> getExonStarts() {
		return exonStarts;
	}





	public void setExonStarts(Vector<Integer> exonStarts) {
		this.exonStarts = exonStarts;
	}





	public Vector<Integer> getExonEnds() {
		return exonEnds;
	}





	public void setExonEnds(Vector<Integer> exonEnds) {
		this.exonEnds = exonEnds;
	}


	public int getLen() {
		return len;
	}


	public void setLen(int len) {
		this.len = len;
	}

	public int getTU() {
		return TU;
	}

	public void setTU(int tU) {
		TU = tU;
	}

	public int getMyID() {
		return myID;
	}

	public void setMyID(int myID) {
		this.myID = myID;
	}


	public int getTss_0based() {
		return tss_0based;
	}

	public void setTss_0based(int tss_0based) {
		this.tss_0based = tss_0based;
	}

	public int getTranslationIS_0based() {
		return translationIS_0based;
	}

	public void setTranslationIS_0based(int translationIS_0based) {
		this.translationIS_0based = translationIS_0based;
	}

	
	public int getDistance_TSS_TIS()
	{
		int dist = getTss_0based() - getTranslationIS_0based();
		return Math.abs(dist);
	}
	
	
	public String toStringBED()
	{
		return this.getChrom() + "\t" + this.getStart() + "\t" + this.getEnd()+ "\t" + this.getName() + "\t"
				+ this.getScore() + "\t"+ this.getStrand() + "\t" + this.getThickStart() + "\t"+ this.getThickEnd() + "\t"
				+ this.getItemRGB() + "\t"+ this.getBlockCount() + "\t"+ this.stringBlockSizes + "\t"+ this.stringBlockStarts  ;

	}

	
	public String toCDS_BED()
	{
		return this.getChrom() + "\t" + this.getThickStart() + "\t" + this.getThickEnd() + "\t" + this.getName() + "\t"
				+ this.getScore() + "\t"+ this.getStrand() + "\t" + this.getThickStart() + "\t"+ this.getThickEnd() + "\t"
				+ this.getItemRGB() + "\t"+ this.getBlockCount() + "\t"+ this.stringBlockSizes + "\t"+ this.stringBlockStarts  ;

	}
	
}

