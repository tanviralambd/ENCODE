package encode.bean;

import java.util.LinkedHashMap;
import java.util.Vector;

public class FastaMult {

	
	
		
		public Vector<String> header = new Vector<String>() ;
		public Vector<String> seq = new Vector<String>();	
		
		/*
		 *  key = header
		 *  value = 0 based index of this header and sequence in two vector header,seq
		 */
		public LinkedHashMap<String, Integer> lhmHeader_VectIndex = new LinkedHashMap<String, Integer>();
		
		
		
		
		public Vector<String> getHeader() {
			return header;
		}
		public void setHeader(Vector<String> header) {
			this.header = header;
		}
		public LinkedHashMap<String, Integer> getLhmHeader_VectIndex() {
			return lhmHeader_VectIndex;
		}
		public void setLhmHeader_VectIndex(
				LinkedHashMap<String, Integer> lhmHeader_VectIndex) {
			this.lhmHeader_VectIndex = lhmHeader_VectIndex;
		}
		public Vector<String> getSeq() {
			return seq;
		}
		public void setSeq(Vector<String> seq) {
			this.seq = seq;
		}
	
		public String toStringPrint()
		{
			StringBuffer buf = new StringBuffer();
			for(int i=0;i<header.size();i++)
			{
				buf.append(header.get(i) + "\n");
				buf.append(seq.get(i) + "\n");
				
			}
			
			return buf+"";
		}

	
}
