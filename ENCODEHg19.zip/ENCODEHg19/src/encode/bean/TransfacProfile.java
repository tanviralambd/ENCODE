package encode.bean;

public class TransfacProfile {

	
	String one;
	String coreSimCutoff;
	String matSimCutoff;
	String accNo;
	String idNo;
	
	public TransfacProfile(String one, String coreSimCutoff,
			String matSimCutoff, String accNo, String idNo) {
		super();
		this.one = one;
		this.coreSimCutoff = coreSimCutoff;
		this.matSimCutoff = matSimCutoff;
		this.accNo = accNo;
		this.idNo = idNo;
	}
	
	public String getOne() {
		return one;
	}
	public void setOne(String one) {
		this.one = one;
	}
	public String getCoreSimCutoff() {
		return coreSimCutoff;
	}
	public void setCoreSimCutoff(String coreSimCutoff) {
		this.coreSimCutoff = coreSimCutoff;
	}
	public String getMatSimCutoff() {
		return matSimCutoff;
	}
	public void setMatSimCutoff(String matSimCutoff) {
		this.matSimCutoff = matSimCutoff;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	
	
	
	
	
}
