package encode.bean;

public class EncodeCellline {

	
	String cellline_Upper;
	String tissue;
	String karyotype;
	String lineage;
	String tier;
	String description;
	
	public EncodeCellline()
	{
		
	}
	
	public EncodeCellline(String cellline_Upper, String tissue,
			String karyotype, String lineage, String tier, String description) {
		super();
		this.cellline_Upper = cellline_Upper;
		this.tissue = tissue;
		this.karyotype = karyotype;
		this.lineage = lineage;
		this.tier = tier;
		this.description = description;
	}
	public String getCellline_Upper() {
		return cellline_Upper;
	}
	public void setCellline_Upper(String cellline_Upper) {
		this.cellline_Upper = cellline_Upper;
	}
	public String getTissue() {
		return tissue;
	}
	public void setTissue(String tissue) {
		this.tissue = tissue;
	}
	public String getKaryotype() {
		return karyotype;
	}
	public void setKaryotype(String karyotype) {
		this.karyotype = karyotype;
	}
	public String getLineage() {
		return lineage;
	}
	public void setLineage(String lineage) {
		this.lineage = lineage;
	}
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
	
}
