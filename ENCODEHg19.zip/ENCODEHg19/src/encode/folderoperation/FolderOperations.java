package encode.folderoperation;

import java.util.Vector;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.io.*;

public class FolderOperations {


	public static Vector<String> listFiles_Files_Dir(String absPathFolder)
	{
		Vector<String> vectAllFiles = new Vector<String>();


		File folder = new File(absPathFolder);
		File[] listOfFiles = folder.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile()) {
				
//				System.out.println("File: " + listOfFiles[i].getName());
				vectAllFiles.add(listOfFiles[i].getName() );
				
			} else if (listOfFiles[i].isDirectory()) {
				
//				System.out.println("Directory: " + listOfFiles[i].getName());
				vectAllFiles.add(listOfFiles[i].getName() );
				
			}
		}

		return vectAllFiles;
	}
	
	/*
	 *   pathCopy  =  Absolute path of existing file 
	 *   pathPaste = Absolute path of new file to be created
	 */

	public static void copy_paste_file(String pathCopy, String pathPaste)
	{
		try {
			File source = new File(pathCopy);
			File dest = new File(pathPaste);
			Files.copy(source.toPath(), dest.toPath() , StandardCopyOption.REPLACE_EXISTING );
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 *  absPathFolder = Absolute path of new folder to be created
	 */
	public static void create_new_folder(String absPathFolder)
	{
		File theDir = new File(absPathFolder);

		// if the directory does not exist, create it
		if (!theDir.exists()) {
			System.out.println("creating directory: " + absPathFolder);

			try{
				theDir.mkdir();
			} catch(SecurityException se){
				se.printStackTrace();
			}

		}
	}


	public static void main(String[] args) {

		FolderOperations obj = new FolderOperations();

		//		 obj.copy_paste_file("./ENCODEname_UNIPROT_HOCOMOCO.txt", "./bin/ENCODEname_UNIPROT_HOCOMOCO.txt");
		//		obj.create_new_folder("./tanvir");
		obj.listFiles_Files_Dir("./") ;


	}
}
