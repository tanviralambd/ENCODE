package encode.encodecage;


import java.util.LinkedHashMap;
import java.util.Vector;

import encode.bean.EncodeCellline;
import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class EncodeCAGE_TissueInformation {

	String fnmFile_Cell_TF_Uniprot="EncodeCage_FileNames_CellLine_Hg19.txt";
	String fnmCell_TissueRepository="Cellines_Hg19.txt";
	String fout="EncodeCage_FileNames_CellLine_Tissue_Hg19.txt";
	
	
//	LinkedHashMap<String, String> lhm_CellLine_Tissue = new LinkedHashMap<String, String>();
	LinkedHashMap<String, EncodeCellline>  lhm_CellLine_Tissue ;
	
	void loadRepository_CellLine_Tissue()
	{
//		lhm_CellLine_Tissue = CommonFunction.readlinesOfAfile_asMap(this.fnmCell_TissueRepository, 0, 1);
		lhm_CellLine_Tissue = CommonFunction.loadEncodeCellline(this.fnmCell_TissueRepository);
		System.out.println("Total Unique cell lines name: " + lhm_CellLine_Tissue.size());
		
	}
	
	
	void addTissueInformation()
	{
		EncodeCellline  cell_Details = new EncodeCellline();
		Vector<String> vectList_FileName_Cell_Tf = CommonFunction.readlinesOfAfile(this.fnmFile_Cell_TF_Uniprot);
		
		StringBuffer res = new StringBuffer();
		
		String fileName,cellName;
		String tfName , tfNameUniprot;
		String tissue;
		
		String tmp[];
		
		for(int i=0; i<vectList_FileName_Cell_Tf.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectList_FileName_Cell_Tf.get(i));
			
			fileName = tmp[0];
			cellName = tmp[1].toUpperCase();
			
			
			
			if(lhm_CellLine_Tissue.containsKey(cellName))
			{
//				tissue = lhm_CellLine_Tissue.get(cellName);
				cell_Details = lhm_CellLine_Tissue.get(cellName);
			}else
			{
				
				tissue = "None";
			}
			
			res.append(fileName + "\t" + 
			cell_Details.getCellline_Upper() + "\t" +  
					cell_Details.getTissue() + "\t" +
					cell_Details.getKaryotype() + "\t"+
					"\n");
		}
		
		CommonFunction.writeContentToFile(this.fout, res + "");
		
	}
	
	
	void doProcessing()
	{
		loadRepository_CellLine_Tissue();
		
		addTissueInformation();
		
	}
	
	public EncodeCAGE_TissueInformation(String fnmFile_Cell_TF_Uniprot,
			String fnmCell_TissueRepository, String fout) {
		super();
		this.fnmFile_Cell_TF_Uniprot = fnmFile_Cell_TF_Uniprot;
		this.fnmCell_TissueRepository = fnmCell_TissueRepository;
		this.fout = fout;
	}


	public static void main(String[] args) {
	
		EncodeCAGE_TissueInformation obj = new EncodeCAGE_TissueInformation( args[0], args[1], args[2]);
		
		
//		
//		EncodeCAGE_TissueInformation obj = new EncodeCAGE_TissueInformation( 
//				"EncodeCage_FileNames_CellLine_Hg19.txt",
//				"Cellines_Hg19.txt", 
//				"EncodeCage_FileNames_CellLine_Tissue_Hg19.txt"
//						);
		
		

		
		obj.doProcessing();
		
		
	}
	
}

