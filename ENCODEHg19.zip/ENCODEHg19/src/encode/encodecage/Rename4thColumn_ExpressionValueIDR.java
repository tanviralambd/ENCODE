package encode.encodecage;



import java.util.LinkedHashMap;
import java.util.Vector;

import encode.bean.Encode;
import encode.bean.EncodeCellline;
import encode.common.CommonFunction;
import encode.constant.ConstantValue;
import encode.folderoperation.FolderOperations;

public class Rename4thColumn_ExpressionValueIDR {


	String fnmFileName_CellLine_Tissue;
	String foldIn;
	String foldOut;

	double thresholdExpression;
	double thresholdIDR;


	LinkedHashMap<String, EncodeCellline> lhm_filename_encObbj = new LinkedHashMap<String, EncodeCellline>();


	public Rename4thColumn_ExpressionValueIDR(
			String fnmFileName_CellLine_Tissue, String foldIn, String foldOut,
			double thresholdExpression, double thresholdIDR) {
		super();
		this.fnmFileName_CellLine_Tissue = fnmFileName_CellLine_Tissue;
		this.foldIn = foldIn;
		this.foldOut = foldOut;
		this.thresholdExpression = thresholdExpression;
		this.thresholdIDR = thresholdIDR;
	}


	void loadFilename_cellline_tissuename()
	{
		Vector<String> vectAll = CommonFunction.readlinesOfAfile(this.fnmFileName_CellLine_Tissue);
		String tmp[];
		String curFilename;
		for(int i=0; i<vectAll.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectAll.get(i));
			curFilename = tmp[0];

			EncodeCellline tmpEnc = new EncodeCellline();

			tmpEnc.setCellline_Upper(tmp[1].toUpperCase());
			tmpEnc.setTissue( tmp[2]);

			lhm_filename_encObbj.put(curFilename, tmpEnc);


		}
	}


	void rename_getExpression_copypaste()
	{

		String curLine="";

		try {

			Vector<String> vectFname = FolderOperations.listFiles_Files_Dir(this.foldIn);
			StringBuffer result = new StringBuffer();

			FolderOperations.create_new_folder(this.foldOut+"/");

			// Now change the 4th column
			String tmp[];
			String curFilename,curCellLine, curTissue;
			String cageExpression;
			float cageValue ;
			double cageExpressionIDR;

			for(int i=0; i<vectFname.size();i++)
			{

				System.out.println("Current file: " + vectFname.get(i) );

				result = null;
				result = new StringBuffer();

				curFilename = vectFname.get(i);
				curCellLine = ((EncodeCellline)lhm_filename_encObbj.get(curFilename)).getCellline_Upper();
				curTissue   = ((EncodeCellline)lhm_filename_encObbj.get(curFilename)).getTissue();


				Vector<String> fileContent = CommonFunction.readlinesOfAfile( this.foldIn+ curFilename);
				for(int line=0; line<fileContent.size();line++)
				{

					curLine = fileContent.get(line);
					tmp = ConstantValue.patTab.split( curLine );
					cageExpression = tmp[6];
					cageValue = Float.parseFloat(cageExpression);

					try  
					{  
						double d = Double.parseDouble( tmp[7]);  
						cageExpressionIDR = d;
					}  
					catch(NumberFormatException nfe)  
					{  
						cageExpressionIDR = 1.00; // discard it  
					}  

//					cageExpressionIDR = Float.parseFloat( tmp[7] );



					if(  (cageValue>= this.thresholdExpression )  &&  ( cageExpressionIDR <= this.thresholdIDR)  )
					{

						result.append(
								tmp[0] + "\t"  +
										tmp[1] + "\t"  +
										tmp[2] + "\t"  +
										(curCellLine+":"+  tmp[3]) + "\t"  +
										cageExpression + "\t"  +
										tmp[5] + "\n"  );


					}

				}

				// Write one file with renamed name
				System.out.println("Writing in file: " + this.foldOut+vectFname.get(i) );
				CommonFunction.writeContentToFile(this.foldOut+vectFname.get(i), result+"");
			}




		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("ERR for line:" + curLine);
		}


	}


	void doProcessing()
	{
		loadFilename_cellline_tissuename();

		rename_getExpression_copypaste();

	}

	public static void main(String[] args) {

		Rename4thColumn_ExpressionValueIDR obj = new Rename4thColumn_ExpressionValueIDR(args[0], args[1], args[2]  
				, Double.parseDouble(args[3])
				, Double.parseDouble(args[4])

				);

		//		Rename4thColumn obj = new Rename4thColumn("EncodeCage_FileNames_CellLine_Tissue_Hg19.txt", 
		//				"./infold/", 
		//				"./outfold/");


		obj.doProcessing();

	}
}

