package encode.encodecage;



import java.util.Vector;

import encode.bean.Encode;
import encode.common.CommonFunction;


/*
 * 
 * Paper :Sequence features and chromatin structure around the genomic regions bound by 119 human transcription factors
 * PMID:
 * 
 * 
 *  Covert Encode Chipseq Filename -> TF name
 *  Basic algo:
 *  file name pattern
 *    wgEncodeRikenCageSknshNucleusPapTssHmm.bedRnaElements
 *   
 *  
 *  1. wgEncodeRikenCage , then
 *  2. Cell Line starts with Capital Letter (e.g. Sknsh) ,  then
 *  3. Location (Nucleus)
 *  4. Some name starts with Capital Letter (PapTssHmm ) 
 *  
 *  
 *  
 *  
 *  So, 3rd pattern is the cellline If we choose letters between (4th Capital Letter to before of 5th Capital Letter)
 *  then we will get the cellline name
 */
public class EncodeCAGE_Filename_CellLine_hg19 {

	String encodeFilename="EncodeCage_FileNames_Hg19.txt";
	String encodeTFname="EncodeCage_FileNames_Cellline_Hg19.txt";
	
	
	void init(String fnmeChip, String fnmTF)
	{
		this.encodeFilename=fnmeChip;
		this.encodeTFname=fnmTF;
	}
	
	void doProcessing()
	{
		Vector<String> vectFileName = CommonFunction.readlinesOfAfile(this.encodeFilename);
		StringBuffer resBuffer = new StringBuffer();
		
		String curFileName;
		String resultCellLine;
		
		
		for(int i=0; i<vectFileName.size();i++)
		{
			curFileName = vectFileName.get(i);
			resultCellLine = CommonFunction.get_cellline_FromCAGEFileName(curFileName);
			
			resBuffer.append( curFileName+"\t" + resultCellLine  + "\n");
			
			
		}
		
		CommonFunction.writeContentToFile(this.encodeTFname, resBuffer+"");
	}
	
	
	public static void main(String[] args) {
		
		EncodeCAGE_Filename_CellLine_hg19 obj = new EncodeCAGE_Filename_CellLine_hg19();
		
		
		
//		obj.init("EncodeCage_FileNames_Hg19.txt", "EncodeCage_FileNames_CellLine_Hg19.txt");
		
		obj.init(args[0], args[1]);
		
		obj.doProcessing();
		
	}
	
}
