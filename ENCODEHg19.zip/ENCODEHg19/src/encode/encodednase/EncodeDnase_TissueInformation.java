package encode.encodednase;


import java.util.LinkedHashMap;
import java.util.Vector;

import encode.bean.EncodeCellline;
import encode.common.CommonFunction;
import encode.constant.ConstantValue;

public class EncodeDnase_TissueInformation {

	String fnmFile_id_cellline="wgEncodeAwgDnaseMasterSources.tab";
	String fnmCell_TissueRepository="Cellines_Hg19.txt";
	String fout="wgEncodeAwgDnaseMasterSources_Tissue.tab";
	
	
//	LinkedHashMap<String, String> lhm_CellLine_Tissue = new LinkedHashMap<String, String>();
	LinkedHashMap<String, EncodeCellline>  lhm_CellLine_Tissue ;
	
	void loadRepository_CellLine_Tissue()
	{
//		lhm_CellLine_Tissue = CommonFunction.readlinesOfAfile_asMap(this.fnmCell_TissueRepository, 0, 1);
		lhm_CellLine_Tissue = CommonFunction.loadEncodeCellline(this.fnmCell_TissueRepository);
		
		System.out.println("Total Unique cell lines name: " + lhm_CellLine_Tissue.size());
		
	}
	
	
	void addTissueInformation()
	{
		EncodeCellline  cell_Details = new EncodeCellline();
		Vector<String> vectList_FileName_Cell_Tf = CommonFunction.readlinesOfAfile(this.fnmFile_id_cellline);
		
		StringBuffer res = new StringBuffer();
		
		String fileID,cellName;
		String tfName , tfNameUniprot;
		String tissue;
		
		String tmp[];
		
		for(int i=0; i<vectList_FileName_Cell_Tf.size();i++)
		{
			tmp = ConstantValue.patTab.split(vectList_FileName_Cell_Tf.get(i));
			
			fileID = tmp[0];
			cellName = tmp[1].toUpperCase();
			
			
			
			if(lhm_CellLine_Tissue.containsKey(cellName))
			{
				cell_Details = lhm_CellLine_Tissue.get(cellName);
			}else
			{
				
				tissue = "None";
			}
			
			res.append(fileID + "\t" + 
			cell_Details.getCellline_Upper() + "\t" +  
					cell_Details.getTissue() + "\t" +
					cell_Details.getKaryotype() + "\t"+
					"\n");
		}
		
		CommonFunction.writeContentToFile(this.fout, res + "");
		
	}
	
	
	void doProcessing()
	{
		loadRepository_CellLine_Tissue();
		
		addTissueInformation();
		
	}
	
	public EncodeDnase_TissueInformation(String fnmFile_Cell_TF_Uniprot,
			String fnmCell_TissueRepository, String fout) {
		super();
		this.fnmFile_id_cellline = fnmFile_Cell_TF_Uniprot;
		this.fnmCell_TissueRepository = fnmCell_TissueRepository;
		this.fout = fout;
	}


	public static void main(String[] args) {
	
		EncodeDnase_TissueInformation obj = new EncodeDnase_TissueInformation( args[0], args[1], args[2]);
		
		
//		
//		EncodeDnase_TissueInformation obj = new EncodeDnase_TissueInformation( 
//				"wgEncodeAwgDnaseMasterSources.tab",
//				"Cellines_Hg19.txt", 
//				"wgEncodeAwgDnaseMasterSources_Tissue.tab"
//						);
		
		

		
		obj.doProcessing();
		
		
	}
	
}

